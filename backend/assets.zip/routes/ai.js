const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { body, validationResult } = require('express-validator');
const {auth} = require('../middleware/auth');
const Product = require('../models/Product');
const StockMovement = require('../models/StockMovement');

const router = express.Router();

// Initialize Gemini AI with enhanced configuration
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ 
  model: "gemini-1.5-pro",
  generationConfig: {
    temperature: 0.7,
    topK: 40,
    topP: 0.95,
    maxOutputTokens: 1024,
  }
});

/**
 * @route   POST /api/ai/chat
 * @desc    AI chat interaction with inventory context using Gemini
 * @access  Private
 */
router.post('/chat', [
  auth,
  [
    body('message').notEmpty().withMessage('Message is required'),
    body('context').optional().isObject()
  ]
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        error: 'Invalid input',
        details: errors.array()
      });
    }

    const { message, context } = req.body;
    const userId = req.user.id;
    const userRole = req.user.role;

    // Extract page context for enhanced responses
    const currentPage = context?.currentPage || '/';
    const pageName = context?.pageName || 'Dashboard';
    const pageContext = context?.pageContext || 'Navigasi sistem';

    // Fetch comprehensive data for AI context (exclude sensitive fields)
    const [products, recentMovements, stockStats, categoryStats, suppliers, customers, orders, stockReportData] = await Promise.all([
      // All products with safe fields only (support both old and new schema)
      Product.find({}, {
        name: 1,
        description: 1,
        category: 1,
        brand: 1,
        price: 1,
        quantity: 1, // Keep for backward compatibility
        minStock: 1, // Keep for backward compatibility  
        maxStock: 1, // Keep for backward compatibility
        stock: 1, // New schema
        unit: 1,
        status: 1,
        location: 1,
        createdAt: 1,
        updatedAt: 1
      }),
      
      // Recent stock movements
      StockMovement.find({}, {
        product: 1,
        type: 1,
        quantity: 1,
        reason: 1,
        notes: 1,
        previousStock: 1,
        createdAt: 1
      }).sort({ createdAt: -1 }).limit(100).populate('product', 'name category'),
      
      // Overall statistics with enhanced dual schema support
      Product.aggregate([
        {
          $addFields: {
            currentStock: {
              $cond: {
                if: { $type: "$stock" },
                then: {
                  $cond: {
                    if: { $type: "$stock.current" },
                    then: "$stock.current",
                    else: { $ifNull: ["$stock", 0] }
                  }
                },
                else: { $ifNull: ["$quantity", 0] }
              }
            },
            minimumStock: {
              $cond: {
                if: { $type: "$stock" },
                then: {
                  $cond: {
                    if: { $type: "$stock.minimum" },
                    then: "$stock.minimum",
                    else: { $ifNull: ["$minStock", 0] }
                  }
                },
                else: { $ifNull: ["$minStock", 0] }
              }
            }
          }
        },
        {
          $group: {
            _id: null,
            totalProducts: { $sum: 1 },
            totalValue: { $sum: { $multiply: [{ $ifNull: ["$price", 0] }, "$currentStock"] } },
            lowStockCount: {
              $sum: { $cond: [{ $lt: ["$currentStock", "$minimumStock"] }, 1, 0] }
            },
            outOfStockCount: {
              $sum: { $cond: [{ $eq: ["$currentStock", 0] }, 1, 0] }
            },
            averagePrice: { $avg: "$price" },
            totalStock: { $sum: "$currentStock" }
          }
        }
      ]),
      
      // Category-wise statistics with enhanced dual schema support
      Product.aggregate([
        {
          $addFields: {
            currentStock: {
              $cond: {
                if: { $type: "$stock" },
                then: {
                  $cond: {
                    if: { $type: "$stock.current" },
                    then: "$stock.current",
                    else: { $ifNull: ["$stock", 0] }
                  }
                },
                else: { $ifNull: ["$quantity", 0] }
              }
            },
            minimumStock: {
              $cond: {
                if: { $type: "$stock" },
                then: {
                  $cond: {
                    if: { $type: "$stock.minimum" },
                    then: "$stock.minimum",
                    else: { $ifNull: ["$minStock", 0] }
                  }
                },
                else: { $ifNull: ["$minStock", 0] }
              }
            }
          }
        },
        {
          $group: {
            _id: "$category",
            count: { $sum: 1 },
            totalValue: { $sum: { $multiply: [{ $ifNull: ["$price", 0] }, "$currentStock"] } },
            avgPrice: { $avg: "$price" },
            totalStock: { $sum: "$currentStock" },
            lowStockItems: {
              $sum: { $cond: [{ $lt: ["$currentStock", "$minimumStock"] }, 1, 0] }
            }
          }
        },
        { $sort: { totalValue: -1 } }
      ]),
      
      // Suppliers (safe fields only)
      require('../models/Supplier').find({}, {
        name: 1,
        contactPerson: 1,
        email: 1,
        phone: 1,
        address: 1,
        status: 1,
        rating: 1,
        productsSupplied: 1
      }).limit(20),
      
      // Customers (safe fields only)  
      require('../models/Customer').find({}, {
        name: 1,
        email: 1,
        phone: 1,
        address: 1,
        totalOrders: 1,
        totalSpent: 1,
        status: 1,
        createdAt: 1
      }).limit(20),
      
      // Recent orders (safe fields only)
      require('../models/Order').find({}, {
        orderNumber: 1,
        customerId: 1,
        items: 1,
        totalAmount: 1,
        status: 1,
        orderDate: 1,
        deliveryDate: 1
      }).sort({ orderDate: -1 }).limit(20).populate('customerId', 'name'),

      // Generate comprehensive stock report data
      (async () => {
        try {
          const allProducts = await Product.find({}).populate('supplier', 'name');
          const allMovements = await StockMovement.find({}).populate('product', 'name category');
          
          // Generate stock report similar to StockReportsManager
          const stockReport = allProducts.map(product => {
            const productId = product._id.toString();
            const movements = allMovements.filter(m => 
              m.product && (m.product._id.toString() === productId || m.product.id === productId)
            );
            
            // Sort movements by date
            const sortedMovements = movements.sort((a, b) => 
              new Date(a.createdAt || a.timestamp).getTime() - new Date(b.createdAt || b.timestamp).getTime()
            );
            
            const stockIn = movements.filter(m => m.type === 'in').reduce((sum, m) => sum + (m.quantity || 0), 0);
            const stockOut = movements.filter(m => m.type === 'out' || m.type === 'damage').reduce((sum, m) => sum + Math.abs(m.quantity || 0), 0);
            const adjustments = movements.filter(m => m.type === 'adjustment' || m.type === 'count').reduce((sum, m) => sum + (m.quantity || 0), 0);
            
            // Enhanced stock extraction with proper type checking
            let currentStock = 0;
            let minimumStock = 0;
            
            if (typeof product.stock === 'object' && product.stock !== null) {
              currentStock = product.stock.current ?? 0;
              minimumStock = product.stock.minimum ?? product.minStock ?? 0;
            } else if (typeof product.stock === 'number') {
              currentStock = product.stock;
              minimumStock = product.minStock ?? 0;
            } else {
              currentStock = product.quantity ?? 0;
              minimumStock = product.minStock ?? 0;
            }
            
            // Get initial stock from the first movement's previousStock, or use current stock
            let initialStock = currentStock;
            if (sortedMovements.length > 0) {
              const firstMovement = sortedMovements[0];
              initialStock = firstMovement.previousStock || 0;
            } else if (stockIn === 0 && stockOut === 0 && adjustments === 0) {
              initialStock = currentStock;
            }
            
            return {
              id: product._id,
              name: product.name,
              category: product.category,
              location: product.location?.warehouse || product.location || '',
              price: product.price || 0,
              currentStock,
              minimumStock,
              stockIn,
              stockOut,
              adjustments,
              initialStock,
              finalStock: currentStock,
              turnover: currentStock > 0 ? (stockOut / currentStock) * 100 : 0,
              stockValue: (product.price || 0) * currentStock,
              status: currentStock < minimumStock ? 'low_stock' : currentStock === 0 ? 'out_of_stock' : 'in_stock',
              recentMovements: sortedMovements.slice(-5).map(m => ({
                type: m.type,
                quantity: m.quantity,
                date: m.createdAt,
                reason: m.reason
              }))
            };
          });
          
          return stockReport;
        } catch (error) {
          console.error('Error generating stock report:', error);
          return [];
        }
      })()
    ]);

    // Prepare comprehensive context for AI including stock report data
    const stats = stockStats[0] || {};
    
    // Calculate stock report summary with data anomaly guard
    const stockSummary = {
      totalItems: stockReportData.length,
      totalValue: stockReportData.reduce((sum, item) => sum + item.stockValue, 0),
      totalStockIn: stockReportData.reduce((sum, item) => sum + item.stockIn, 0),
      totalStockOut: stockReportData.reduce((sum, item) => sum + item.stockOut, 0),
      averageTurnover: stockReportData.length > 0 ? stockReportData.reduce((sum, item) => sum + item.turnover, 0) / stockReportData.length : 0,
      lowStockItems: stockReportData.filter(item => item.status === 'low_stock').length,
      outOfStockItems: stockReportData.filter(item => item.status === 'out_of_stock').length,
      highTurnoverItems: stockReportData.filter(item => item.turnover > 50).length,
    };

    // Data anomaly guard - check for suspicious all-zero scenario
    const hasStockMovements = recentMovements.length > 0;
    const allProductsOutOfStock = stockSummary.totalItems > 0 && stockSummary.outOfStockItems === stockSummary.totalItems;
    const dataAnomalyDetected = allProductsOutOfStock && hasStockMovements;
    
    if (dataAnomalyDetected) {
      console.warn('🚨 Data anomaly detected: All products appear out of stock despite recent movements');
    }
    
    // Top performing items by various metrics
    const topValueItems = [...stockReportData].sort((a, b) => b.stockValue - a.stockValue).slice(0, 5);
    const highTurnoverItems = [...stockReportData].sort((a, b) => b.turnover - a.turnover).slice(0, 5);
    const lowStockAlerts = stockReportData.filter(item => item.status === 'low_stock').slice(0, 10);
    
    const inventoryContext = {
      // Page context (NEW FEATURE)
      currentPage: currentPage,
      pageName: pageName,
      pageContext: pageContext,
      
      // Overall statistics
      totalProducts: stats.totalProducts || 0,
      totalValue: stats.totalValue || 0,
      totalStock: stats.totalStock || 0,
      averagePrice: stats.averagePrice || 0,
      lowStockCount: stats.lowStockCount || 0,
      outOfStockCount: stats.outOfStockCount || 0,
      
      // Recent activity
      recentMovements: recentMovements.length,
      recentMovementTypes: recentMovements.reduce((acc, mv) => {
        acc[mv.type] = (acc[mv.type] || 0) + 1;
        return acc;
      }, {}),
      
      // Product data
      categories: [...new Set(products.map(p => p.category))].filter(Boolean),
      brands: [...new Set(products.map(p => p.brand))].filter(Boolean),
      locations: [...new Set(products.map(p => p.location))].filter(Boolean),
      
      // Category performance
      categoryStats: categoryStats.map(cat => ({
        category: cat._id,
        productCount: cat.count,
        totalValue: cat.totalValue,
        averagePrice: cat.avgPrice,
        totalStock: cat.totalStock,
        lowStockItems: cat.lowStockItems
      })),
      
      // Sample products for reference with enhanced dual schema support
      sampleProducts: products.slice(0, 10).map(p => {
        // Enhanced stock extraction with proper type checking
        let currentStock = 0;
        let minimumStock = 0;
        
        if (typeof p.stock === 'object' && p.stock !== null) {
          currentStock = p.stock.current ?? 0;
          minimumStock = p.stock.minimum ?? p.minStock ?? 0;
        } else if (typeof p.stock === 'number') {
          currentStock = p.stock;
          minimumStock = p.minStock ?? 0;
        } else {
          currentStock = p.quantity ?? 0;
          minimumStock = p.minStock ?? 0;
        }
        
        return {
          name: p.name,
          category: p.category,
          brand: p.brand,
          price: p.price,
          stock: currentStock,
          minStock: minimumStock,
          unit: p.unit,
          location: p.location,
          status: currentStock < minimumStock ? 'low_stock' : currentStock === 0 ? 'out_of_stock' : 'in_stock'
        };
      }),
      
      // Business data
      supplierCount: suppliers.length,
      customerCount: customers.length,
      recentOrdersCount: orders.length,
      
      // User context
      userRole: userRole,
      timestamp: new Date().toISOString(),
      
      // STOCK REPORT DATA - COMPREHENSIVE INVENTORY ANALYSIS
      stockReport: {
        summary: stockSummary,
        topValueItems: topValueItems.map(item => ({
          name: item.name,
          category: item.category,
          stockValue: item.stockValue,
          currentStock: item.currentStock,
          turnover: item.turnover
        })),
        highTurnoverItems: highTurnoverItems.map(item => ({
          name: item.name,
          category: item.category,
          turnover: item.turnover,
          stockOut: item.stockOut,
          currentStock: item.currentStock
        })),
        lowStockAlerts: lowStockAlerts.map(item => ({
          name: item.name,
          category: item.category,
          currentStock: item.currentStock,
          minimumStock: item.minimumStock,
          location: item.location,
          status: item.status
        })),
        categoryBreakdown: categoryStats.map(cat => ({
          category: cat._id,
          itemCount: cat.count,
          totalValue: cat.totalValue,
          lowStockCount: cat.lowStockItems
        })),
        recentActivity: recentMovements.slice(0, 20).map(m => ({
          productName: m.product?.name || 'Unknown Product',
          type: m.type,
          quantity: m.quantity,
          date: m.createdAt,
          reason: m.reason
        }))
      }
    };

    // Enhanced page-aware Gemini prompt with comprehensive stock report context and anomaly detection
    const prompt = `
Kamu adalah AI assistant cerdas untuk sistem inventory management PT. XYZ. Berikan analisis mendalam dan jawaban yang sangat helpful dalam bahasa Indonesia.

=== KONTEKS HALAMAN SAAT INI ===
USER SEDANG DI HALAMAN: ${pageName} (${currentPage})
KONTEKS HALAMAN: ${pageContext}

${dataAnomalyDetected ? '⚠️ PERHATIAN: Terdeteksi kemungkinan anomali data - semua produk tampak stok habis meski ada aktivitas. Berikan analisis dengan hati-hati.' : ''}

=== LAPORAN STOK LENGKAP (DATA REAL-TIME) ===

RINGKASAN STOK:
- Total Item dalam Stok: ${stockSummary.totalItems}
- Total Nilai Inventory: Rp ${stockSummary.totalValue.toLocaleString('id-ID')}
- Total Barang Masuk: ${stockSummary.totalStockIn} unit
- Total Barang Keluar: ${stockSummary.totalStockOut} unit
- Rata-rata Perputaran Stok: ${stockSummary.averageTurnover.toFixed(1)}%
- Item Stok Menipis: ${stockSummary.lowStockItems}
- Item Stok Habis: ${stockSummary.outOfStockItems}
- Item Perputaran Tinggi (>50%): ${stockSummary.highTurnoverItems}

ITEM BERNILAI TINGGI (Top 5):
${topValueItems.map(item => 
  `- ${item.name} (${item.category}): Nilai Rp ${item.stockValue.toLocaleString('id-ID')}, Stok: ${item.currentStock}, Perputaran: ${item.turnover.toFixed(1)}%`
).join('\n')}

ITEM PERPUTARAN TINGGI (Top 5):
${highTurnoverItems.map(item => 
  `- ${item.name} (${item.category}): Perputaran ${item.turnover.toFixed(1)}%, Keluar: ${item.stockOut}, Stok: ${item.currentStock}`
).join('\n')}

ALERT STOK MENIPIS:
${lowStockAlerts.map(item => 
  `- ${item.name} (${item.category}): ${item.currentStock}/${item.minimumStock} di ${item.location || 'N/A'}`
).join('\n')}

BREAKDOWN KATEGORI:
${inventoryContext.stockReport.categoryBreakdown.map(cat => 
  `- ${cat.category}: ${cat.itemCount} item, Nilai: Rp ${cat.totalValue.toLocaleString('id-ID')}, Stok menipis: ${cat.lowStockCount}`
).join('\n')}

AKTIVITAS TERBARU (20 terakhir):
${inventoryContext.stockReport.recentActivity.slice(0, 10).map(act => 
  `- ${act.productName}: ${act.type} ${act.quantity} (${act.reason || 'N/A'}) - ${new Date(act.date).toLocaleDateString('id-ID')}`
).join('\n')}

=== DATA INVENTORY REAL-TIME ===

STATISTIK UMUM:
- Total Produk: ${inventoryContext.totalProducts}
- Total Nilai Inventory: Rp ${(inventoryContext.totalValue || 0).toLocaleString('id-ID')}
- Total Stok: ${inventoryContext.totalStock} unit
- Harga Rata-rata: Rp ${(inventoryContext.averagePrice || 0).toLocaleString('id-ID')}
- Produk Stok Menipis: ${inventoryContext.lowStockCount}
- Produk Stok Habis: ${inventoryContext.outOfStockCount}

AKTIVITAS TERBARU:
- Pergerakan Stok 24 jam terakhir: ${inventoryContext.recentMovements}
- Jenis pergerakan: ${Object.entries(inventoryContext.recentMovementTypes || {}).map(([type, count]) => `${type} (${count}x)`).join(', ')}

KATEGORI PRODUK (${inventoryContext.categories.length} kategori):
${inventoryContext.categories.join(', ')}

BUSINESS DATA:
- Supplier: ${inventoryContext.supplierCount}
- Customer: ${inventoryContext.customerCount}  
- Order Terbaru: ${inventoryContext.recentOrdersCount}

USER CONTEXT:
- Role: ${userRole}
- Halaman: ${pageName}
- Waktu Query: ${new Date().toLocaleString('id-ID')}

=== PERTANYAAN USER ===
"${message}"

=== INSTRUKSI RESPON ===
Berikan jawaban yang:
1. SADAR KONTEKS HALAMAN - sesuaikan jawaban dengan halaman ${pageName} yang sedang user akses
2. Berdasarkan data LAPORAN STOK REAL-TIME di atas (jangan buat-buat data)
3. Prioritaskan informasi dari LAPORAN STOK yang paling relevan
4. Spesifik dengan angka dan detail yang relevan untuk halaman ini
5. Memberikan insight bisnis yang berguna untuk konteks ${pageContext}
6. Menyarankan tindakan konkret yang bisa dilakukan di halaman ${pageName}
7. Maksimal 3-4 kalimat, langsung to the point
8. Gunakan data laporan stok untuk memberikan analisis mendalam

FOKUS KHUSUS BERDASARKAN HALAMAN:
- Jika di halaman Products: fokus pada data produk, stok, kategori dari laporan
- Jika di halaman Inventory: fokus pada pergerakan stok, stock opname dari laporan  
- Jika di halaman Stock Reports: berikan insights mendalam dari laporan stok
- Jika di halaman Vendors: fokus pada supplier dan procurement analysis
- Jika di halaman Reports: fokus pada analytics dan business intelligence dari laporan

Jawab langsung tanpa prefix "AI:" atau sejenisnya.
`;

    let response = '';
    let suggestions = [];

    try {
      // Get AI response from Gemini
      if (process.env.GEMINI_API_KEY) {
        const result = await model.generateContent(prompt);
        response = result.response.text().trim();
      } else {
        // Fallback to rule-based response if no API key
        throw new Error('Gemini API key not configured');
      }
    } catch (aiError) {
      console.log('Gemini AI not available, using enhanced fallback:', aiError.message);
      
      // Enhanced page-aware fallback response with comprehensive data
      const lowerMessage = message.toLowerCase();
      const stats = stockStats[0] || {};
      
      // Page-specific fallback responses
      if (currentPage === '/products' && (lowerMessage.includes('produk') || lowerMessage.includes('stok'))) {
        const lowStockProducts = products.filter(p => p.quantity < p.minStock);
        response = `Di halaman Products: ${stats.totalProducts || 0} produk terdaftar, ${lowStockProducts.length} stok menipis. `;
        
        if (lowStockProducts.length > 0) {
          const topLowStock = lowStockProducts.slice(0, 3);
          response += `Yang urgent: ${topLowStock.map(p => `${p.name} (${p.quantity}/${p.minStock})`).join(', ')}.`;
        }
      } else if (currentPage === '/inventory' && lowerMessage.includes('inventory')) {
        response = `Inventory Status: Total stok ${stats.totalStock || 0} unit, ${recentMovements.length} pergerakan hari ini. `;
        response += `${stats.lowStockCount || 0} item perlu reorder, ${stats.outOfStockCount || 0} habis stok.`;
      } else if (currentPage === '/vendors' && (lowerMessage.includes('supplier') || lowerMessage.includes('vendor'))) {
        response = `Vendor Management: ${suppliers.length} supplier terdaftar. Data lengkap supplier tersedia untuk evaluasi performa dan procurement optimization.`;
      } else if (currentPage === '/orders' && lowerMessage.includes('order')) {
        response = `Order Management: ${orders.length} order terbaru dari ${customers.length} customer. Revenue tracking dan customer analysis tersedia.`;
      } else if (lowerMessage.includes('analisis') || lowerMessage.includes('analyze')) {
        response = `📊 Analisis ${pageName}: Data real-time menunjukkan ${stats.totalProducts || 0} produk (Rp ${(stats.totalValue || 0).toLocaleString('id-ID')}). `;
        response += `${stats.lowStockCount || 0} item stok menipis di ${inventoryContext.categories.length} kategori.`;
      } else if (lowerMessage.includes('laporan') || lowerMessage.includes('report')) {
        response = `📈 Laporan ${pageName}: Total inventory Rp ${(stats.totalValue || 0).toLocaleString('id-ID')}, `;
        response += `${recentMovements.length} transaksi hari ini, ${suppliers.length} supplier aktif.`;
      } else if (lowerMessage.includes('kategori')) {
        if (categoryStats.length > 0) {
          const topCategory = categoryStats[0];
          response = `Kategori Analysis: ${topCategory._id} leading dengan ${topCategory.count} produk (Rp ${topCategory.totalValue.toLocaleString('id-ID')}). `;
          response += `${categoryStats.length} kategori total tersedia.`;
        }
      } else {
        // Default page-aware response
        response = `${pageName} Dashboard: ${stats.totalProducts || 0} produk (Rp ${(stats.totalValue || 0).toLocaleString('id-ID')}), `;
        response += `${stats.lowStockCount || 0} stok menipis, ${recentMovements.length} aktivitas terbaru. `;
        response += `Konteks: ${pageContext}. Ada yang bisa dibantu?`;
      }
    }

    // Generate smart contextual suggestions based on current page and data
    const lowerMessage = message.toLowerCase();
    suggestions = [];
    
    // Page-specific suggestions
    if (currentPage === '/products') {
      suggestions = [
        `${inventoryContext.lowStockCount} produk stok menipis`,
        'Best seller analysis',
        'Slow moving products',
        'Kategori performance'
      ];
    } else if (currentPage === '/inventory') {
      suggestions = [
        'Stock opname schedule',
        `${inventoryContext.recentMovements} pergerakan terbaru`,
        'Location optimization',
        'Inventory turnover'
      ];
    } else if (currentPage === '/vendors') {
      suggestions = [
        `${inventoryContext.supplierCount} supplier performance`,
        'Lead time analysis',
        'Vendor cost comparison',
        'Supplier reliability'
      ];
    } else if (currentPage === '/orders') {
      suggestions = [
        `${inventoryContext.recentOrdersCount} order terbaru`,
        'Customer behavior analysis',
        'Revenue tracking',
        'Order fulfillment rate'
      ];
    } else if (currentPage === '/reports') {
      suggestions = [
        'Generate comprehensive report',
        'Business intelligence insights',
        'Trend analysis',
        'ROI calculation'
      ];
    } else {
      // Default dashboard suggestions
      suggestions = [
        `${inventoryContext.lowStockCount} item stok menipis`,
        `${inventoryContext.categories.length} kategori analysis`,
        `${inventoryContext.recentMovements} aktivitas terbaru`,
        'System overview'
      ];
    }
    
    // Add urgent alerts to top of suggestions
    if (inventoryContext.outOfStockCount > 0) {
      suggestions.unshift(`URGENT: ${inventoryContext.outOfStockCount} produk habis!`);
    }

    // Add role-specific suggestions
    if (userRole === 'admin' || userRole === 'superadmin') {
      suggestions.push('System monitoring', 'User management');
    }

    res.json({
      success: true,
      data: {
        response,
        suggestions,
        timestamp: new Date().toISOString(),
        dataSource: 'real-time',
        aiProvider: process.env.GEMINI_API_KEY ? 'gemini' : 'enhanced-fallback',
        pageContext: {
          currentPage: currentPage,
          pageName: pageName,
          context: pageContext
        },
        context: {
          totalProducts: stockStats[0]?.totalProducts || 0,
          lowStockCount: stockStats[0]?.lowStockCount || 0,
          recentMovements: recentMovements.length,
          supplierCount: suppliers.length,
          customerCount: customers.length
        }
      }
    });

  } catch (error) {
    console.error('AI Chat Error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process AI request',
      message: error.message
    });
  }
});

/**
 * @route   POST /api/ai/enhanced-chat
 * @desc    Enhanced AI chat with additional features (alias for /chat with enhanced processing)
 * @access  Private
 */
router.post('/enhanced-chat', [
  auth,
  [
    body('message').notEmpty().withMessage('Message is required'),
    body('context').optional().isObject()
  ]
], async (req, res) => {
  // Enhanced chat is just an alias to the main chat with additional context processing
  // Forward to main chat endpoint with enhanced context
  req.body.context = {
    ...req.body.context,
    enhanced: true,
    timestamp: new Date().toISOString()
  };
  
  // Call the main chat handler
  return router.handle(req.method, req.url.replace('/enhanced-chat', '/chat'), req, res);
});

// @desc    Get AI suggestions based on current data and page context
// @route   GET /api/ai/suggestions
// @access  Private
router.get('/suggestions', auth, async (req, res) => {
  try {
    const userRole = req.user.role;
    const currentPage = req.query.page || '/';
    
    // Get contextual data with dual schema support
    const [lowStockCount, recentMovementsCount, totalProducts, supplierCount, customerCount] = await Promise.all([
      Product.countDocuments({
        $expr: { 
          $lt: [
            { $ifNull: ["$stock.current", { $ifNull: ["$quantity", 0] }] },
            { $ifNull: ["$stock.minimum", { $ifNull: ["$minStock", 0] }] }
          ]
        },
        status: 'active'
      }),
      StockMovement.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
      }),
      Product.countDocuments({ status: 'active' }),
      require('../models/Supplier').countDocuments({ status: 'active' }),
      require('../models/Customer').countDocuments({ status: 'active' })
    ]);

    // Page-specific suggestions
    let suggestions = [];
    
    switch (currentPage) {
      case '/products':
        suggestions = [
          `Cek ${lowStockCount} produk stok rendah`,
          'Analisis best seller products',
          'Review slow moving items',
          'Optimasi kategori produk'
        ];
        break;
      case '/inventory':
        suggestions = [
          `Review ${recentMovementsCount} pergerakan hari ini`,
          'Schedule stock opname',
          'Analisis inventory velocity',
          'Optimasi lokasi penyimpanan'
        ];
        break;
      case '/vendors':
        suggestions = [
          `Evaluasi ${supplierCount} supplier`,
          'Analisis supplier performance',
          'Review lead time suppliers',
          'Negoisasi harga vendor terbaik'
        ];
        break;
      case '/orders':
        suggestions = [
          'Review pending orders',
          `Analisis ${customerCount} customer behavior`,
          'Track order fulfillment rate',
          'Revenue trend analysis'
        ];
        break;
      default:
        suggestions = [
          `Status ${totalProducts} produk inventory`,
          `${lowStockCount} item perlu restock`,
          `${recentMovementsCount} aktivitas hari ini`,
          'Dashboard overview analytics'
        ];
    }

    // Role-based additional suggestions
    if (userRole === 'admin' || userRole === 'superadmin') {
      suggestions.push('System health monitoring', 'User activity analysis');
    }

    res.json({
      success: true,
      data: {
        suggestions,
        pageContext: currentPage,
        dataSnapshot: {
          totalProducts,
          lowStockCount,
          recentMovementsCount,
          supplierCount,
          customerCount
        }
      }
    });

  } catch (error) {
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

module.exports = router;